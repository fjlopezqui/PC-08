﻿class ArregloEnteros {
    static void Main() {

        int numeroDelUsuario; //Variable para almacenar el número ingresado por el usuario y ser utilizado afuera del bucle do-while
        bool validezNumero; //Variable que controla la validez de la entrada
        int[] arregloEnteros = new int[8];

        for (int i = 0; i<arregloEnteros.Length; i++) { //Se realiza una cantidad de 8 veces, puesto que el proceso de validación de datos se debe realizar repetitivamente
            do //Explicación en el while
            {
                Console.WriteLine($"Iteración no. {i+1}");
                Console.Write("Ingrese un número positivo entero: "); //El usuario ingresa un número en formato string
                string entradaDeUsuario = Console.ReadLine()!; //Se lee la entrada 
    
                if (int.TryParse(entradaDeUsuario, out numeroDelUsuario)) //Intenta convertir la entrada a un número entero
                {
                    
                    if (numeroDelUsuario > 0) //Verifica que el número es positivo
                    {
                        arregloEnteros[i] = numeroDelUsuario; //La variable contadora (que inicia en 0) registra el número en el arreglo
                        Console.WriteLine($"Se registró el número {numeroDelUsuario}"); //Se imprime un mensaje para avisar que se imprimió el número
                        validezNumero = true; //Se valida que el dato sí es válido

                    }
                    else //Si el número es negativo
                    {
                        Console.WriteLine("Entrada inválida, no es un número positivo. Inténtalo de nuevo."); //Mensaje para el usuario para que sepa que ingresó un número negativo
                        validezNumero = false; //Entada inválida
                    }
                }
                else //Si la conversión no pudo ser posible
                {
                    Console.WriteLine("Entrada inválida, no es un número o es un número con decimales. Inténtalo de nuevo."); //Mensaje para el usuario para que sepa que ingresó un dato que no era número o era un número con decimales
                    validezNumero = false; //Entada inválida
                }


            }
            while (!validezNumero); //Mientras que el número no sea válido, siempre se estará dentro del ciclo
        }
        
        int sumaNumeros = 0; //Se declara e inicia la variable que registra la suma de los números
        foreach (var numero in arregloEnteros) { 
            sumaNumeros += numero; //Cada número se va sumando en la variable de suma total
        }

        double promedioNumeros = sumaNumeros / 8.00; //Se divide la suma entre 8 (porque siempre serán 8 números) para obtener su promedio.
        
        string impresionArreglo = String.Join(",", arregloEnteros); //Se unen los números en una string para que se pueda imprimir
        Console.WriteLine($"Los numeros ingresados fueron: {impresionArreglo}"); //Se imprime la lista de  números
        Console.WriteLine($"La suma de los números es: {sumaNumeros}"); //Se imprime la suma de los números
        Console.WriteLine($"El promedio de los números es: {promedioNumeros}"); //Se imprime el promedio de los números

        Console.ReadKey();
    }



}