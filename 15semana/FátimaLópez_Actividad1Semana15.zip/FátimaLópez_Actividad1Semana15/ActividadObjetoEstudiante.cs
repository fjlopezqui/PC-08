﻿public class Estudiante {
    public string? Nombre;
    public int Edad;
    public string? Carrera;
    public string? Carnet;
    public int NotaAdmision;

    public Estudiante(string Nombre, int Edad, string Carrera, string Carnet, int NotaAdmision)
    {
        this.Nombre = Nombre;
        this.Edad = Edad;
        this.Carrera = Carrera;
        this.Carnet = Carnet;
        this.NotaAdmision = NotaAdmision;

    }

    public void MostrarResumen()
    {
        Console.WriteLine($"El nombre del estudiante es: {this.Nombre}");
        Console.WriteLine($"La edad del estudiante es: {this.Edad}");
        Console.WriteLine($"La carrera del estudiante es: {this.Carrera}");
        Console.WriteLine($"El carnet del estudiante es: {this.Carnet}");
    }

    public void PuedeMatricular()
    {
        if (this.NotaAdmision >= 75)
        {
            Console.WriteLine("El estudiante puede matricularse");
        }
        else
        {
            Console.WriteLine("El estudiante NO puede matricularse");
        }
    }

}

public class ActividadObjetoEstudiante() 
{
    public static string ValidarCarnet()
    {
        Console.WriteLine("Ingrese su carnet: ");
        string usuarioCarnet = Console.ReadLine()!;
        bool terminaCon = usuarioCarnet.EndsWith("2025");
        do 
        {
            if (terminaCon)
            {
                return usuarioCarnet;
            }
            else 
            {
                Console.WriteLine("El año que termina su carnet no es válido, vuelva a ingresar un carnet válido");
                usuarioCarnet = Console.ReadLine()!;
                terminaCon = usuarioCarnet.EndsWith("2025");
            }
        }
        while (true);
        
    }

    public static void Main()
    {
        Console.WriteLine("Ingrese su nombre: ");
        string nombreUsuario = Console.ReadLine()!;

        Console.Write("Ingrese su edad: ");
        int edadUsuario = int.Parse(Console.ReadLine()!);

        Console.WriteLine("Ingrese su carrera: ");
        string carreraUsuario = Console.ReadLine()!;

        string carnetUsuario = ValidarCarnet();

        Console.Write("Ingrese su nota de examen de admisión: ");
        int notaUsuario = int.Parse(Console.ReadLine()!);

        Estudiante nuevoEstudiante = new Estudiante(nombreUsuario, edadUsuario, carreraUsuario, carnetUsuario, notaUsuario);
        nuevoEstudiante.MostrarResumen();
        nuevoEstudiante.PuedeMatricular();
 
        
    }
}